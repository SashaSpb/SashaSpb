#
#  Базовые операции языка
#

# Объявление переменных
a = 10
b = 15 + 14
c = a * 2
d = b + c

# Вывод данных
print(10)
print(a)
print("Hello world")
print("Hello", "YourName")

# Ввод данных
your_name = input("Введите ваше имя: ")
your_age = int(input("Введите ваш возраст: "))  # преобразовали в int число
